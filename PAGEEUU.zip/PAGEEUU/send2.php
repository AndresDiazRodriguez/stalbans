<?php


header("location: https://link.clover.com/urlshortener/KC9zkD");



?>