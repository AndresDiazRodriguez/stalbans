<?php


header("location: https://link.clover.com/urlshortener/c2k67V");



?>