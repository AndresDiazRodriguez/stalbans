<?php


header("location: https://link.clover.com/urlshortener/tNy68B");



?>